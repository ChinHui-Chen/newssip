"""Generic data elements that can be returned by content extractors"""

class Record: pass

class Post(Record): pass
    
class Profile(Record): pass

class Quote(Record): pass



